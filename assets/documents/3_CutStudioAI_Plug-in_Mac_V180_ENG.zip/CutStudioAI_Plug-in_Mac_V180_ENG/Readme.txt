*************************************************************
        Roland CutStudio Plug-in for Adobe Illustrator
        [Mac OS version]
*************************************************************

We recommend that you read through this document first to get a better understanding of Roland CutStudio Plug-in for Adobe Illustrator. This "Readme" file provides some important information about installing and setting up this program.
The explanations here assume that you are already familiar with using in Macintosh.


Table of Contents

1.  Summary
2.  Compatible Versions
3.  Installation


* Macintosh and Mac OS are registered trademark of Apple Inc. in the United States and/or other countries.
* Adobe and Illustrator are either registered trademarks or trademarks of Adobe Systems Incorporated in the United States and/or other countries.
Other company and product names appearing herein are trademarks or registered trademarks of their respective holders.

Copyright (C) 2006-2015 Roland DG Corporation


R5-150122


========================================================
1.  Summary 
========================================================

This is a software plug-in for Adobe Illustrator (Mac OS version).
The plug-in lets you output plotted paths to the Roland Vinyl Cutters and cut media.


========================================================
2.  Compatible Versions
========================================================

This plug-in works with Adobe Illustrator CS5, CS5.1, CS6, CC and CC2014.
The plug-ins cannot run at "PowerPC".


========================================================
4.  Installation
========================================================

Expanding the downloaded file creates the following files in the folder where expanded.

	CutStudioPlugInCS5.zxp	Software plug-in for Adobe Illustrator CS5 to CS5.1
	CutStudioPlugin.zxp	Software plug-in for Adobe Illustrator CS6 to CC2014
	CutStudio		Folder included in outputting program and help files
	Readme.txt		Information about installing (in English)

Copy the specified files to the specified locations.
The plug-in may not work correctly if files are copied to the wrong location.


Procedure

1.Log on to the computer connected with this machine as an administrator.
2.If Adobe Illustrator is running, quit the program.
3.Start the Adobe Extension Manager.
4.Select the Illustrator version you use in [Products] section, and click [Install].
5.Select "CutStudioPlugIn.zxp" ("CutStudioPlugInCS5.zxp" when using CS5/5.1), and click [Open].
6.Click [Install] when a confirm dialog is displayed.
7.Copy the [CutStudio] folder to the [Applications] folder in the hard disk.

Installing plug-in software completes.


========================================================

If you have further questions or problem, please contact to your local vendor or Roland sales center.
